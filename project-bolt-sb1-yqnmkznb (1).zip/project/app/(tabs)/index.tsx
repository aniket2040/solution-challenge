import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Mic, MessageSquare, BookOpen } from 'lucide-react-native';
import * as Speech from 'expo-speech';

export default function LearnScreen() {
  const insets = useSafeAreaInsets();
  const [isListening, setIsListening] = useState(false);

  const handleVoiceInput = async () => {
    if (Platform.OS === 'web') {
      // Voice input not supported on web
      return;
    }

    if (isListening) {
      Speech.stop();
      setIsListening(false);
    } else {
      setIsListening(true);
      try {
        await Speech.speak('How can I help you learn today?');
      } catch (error) {
        console.error('Speech error:', error);
      }
      setIsListening(false);
    }
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <Text style={styles.greeting}>Hello, Student! 👋</Text>
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Continue Learning</Text>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Algebra Basics</Text>
            <Text style={styles.cardProgress}>Progress: 60%</Text>
            <TouchableOpacity style={styles.continueButton}>
              <Text style={styles.buttonText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionsGrid}>
            <TouchableOpacity style={styles.actionButton} onPress={handleVoiceInput}>
              <Mic size={24} color="#6366f1" />
              <Text style={styles.actionText}>Voice Ask</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <MessageSquare size={24} color="#6366f1" />
              <Text style={styles.actionText}>Chat Help</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <BookOpen size={24} color="#6366f1" />
              <Text style={styles.actionText}>Practice</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recommended</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.recommendedScroll}>
            {['Physics', 'Chemistry', 'Biology'].map((subject, index) => (
              <TouchableOpacity key={index} style={styles.recommendedCard}>
                <Text style={styles.recommendedTitle}>{subject}</Text>
                <Text style={styles.recommendedDesc}>New lessons available</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  greeting: {
    fontSize: 24,
    fontWeight: '700',
    padding: 20,
    color: '#1e293b',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
    color: '#334155',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  cardProgress: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
  continueButton: {
    backgroundColor: '#6366f1',
    padding: 8,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 12,
  },
  buttonText: {
    color: '#ffffff',
    fontWeight: '600',
  },
  actionsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  actionText: {
    marginTop: 8,
    fontSize: 12,
    color: '#475569',
    fontWeight: '500',
  },
  recommendedScroll: {
    flexDirection: 'row',
  },
  recommendedCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginRight: 12,
    width: 160,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  recommendedTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  recommendedDesc: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
});