import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Search, BookOpen, Star, Clock } from 'lucide-react-native';
import VideoPlayer from '../../components/VideoPlayer';

// Sample video data for subjects
const subjects = [
  {
    name: 'Mathematics',
    progress: 75,
    videoUrl: 'https://www.youtube.com/embed/X_KWMRVdvO0',
    description: 'Introduction to Algebra',
  },
  {
    name: 'Physics',
    progress: 60,
    videoUrl: 'https://www.youtube.com/embed/ZM8ECpBuQYE',
    description: 'Understanding Motion',
  },
  {
    name: 'Chemistry',
    progress: 45,
    videoUrl: 'https://www.youtube.com/embed/bka20Q9TN6M',
    description: 'Atomic Structure',
  },
  {
    name: 'Biology',
    progress: 30,
    videoUrl: 'https://www.youtube.com/embed/QnQe0xW_JY4',
    description: 'Cell Structure and Function',
  },
];

export default function LibraryScreen() {
  const insets = useSafeAreaInsets();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVideo, setSelectedVideo] = useState<{
    url: string;
    title: string;
  } | null>(null);

  const handleSubjectPress = (subject: typeof subjects[0]) => {
    setSelectedVideo({
      url: subject.videoUrl,
      title: `${subject.name} - ${subject.description}`,
    });
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <Text style={styles.title}>Library</Text>
      
      <View style={styles.searchContainer}>
        <Search size={20} color="#64748b" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search subjects, topics..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Subjects</Text>
          {subjects.map((subject, index) => (
            <TouchableOpacity
              key={index}
              style={styles.subjectCard}
              onPress={() => handleSubjectPress(subject)}
            >
              <View style={styles.subjectInfo}>
                <BookOpen size={24} color="#6366f1" />
                <View style={styles.subjectDetails}>
                  <Text style={styles.subjectName}>{subject.name}</Text>
                  <Text style={styles.subjectDescription}>{subject.description}</Text>
                  <View style={styles.progressBar}>
                    <View style={[styles.progressFill, { width: `${subject.progress}%` }]} />
                  </View>
                </View>
              </View>
              <Text style={styles.progressText}>{subject.progress}%</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Access</Text>
          <View style={styles.quickAccessGrid}>
            <TouchableOpacity style={styles.quickAccessCard}>
              <Star size={24} color="#6366f1" />
              <Text style={styles.quickAccessText}>Favorites</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickAccessCard}>
              <Clock size={24} color="#6366f1" />
              <Text style={styles.quickAccessText}>Recent</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recommended Topics</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {['Calculus', 'Quantum Physics', 'Organic Chemistry'].map((topic, index) => (
              <TouchableOpacity key={index} style={styles.topicCard}>
                <Text style={styles.topicTitle}>{topic}</Text>
                <Text style={styles.topicDesc}>Advanced Level</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </ScrollView>

      {selectedVideo && (
        <VideoPlayer
          isVisible={!!selectedVideo}
          onClose={() => setSelectedVideo(null)}
          videoUrl={selectedVideo.url}
          title={selectedVideo.title}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    padding: 20,
    color: '#1e293b',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    margin: 20,
    borderRadius: 12,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#1e293b',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
    color: '#334155',
  },
  subjectCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  subjectInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  subjectDetails: {
    marginLeft: 12,
    flex: 1,
  },
  subjectName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 4,
  },
  subjectDescription: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 8,
  },
  progressBar: {
    height: 4,
    backgroundColor: '#e2e8f0',
    borderRadius: 2,
    overflow: 'hidden',
    width: '100%',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#6366f1',
  },
  progressText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6366f1',
    marginLeft: 12,
  },
  quickAccessGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  quickAccessCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    flex: 1,
    marginHorizontal: 4,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  quickAccessText: {
    marginTop: 8,
    fontSize: 14,
    color: '#475569',
  },
  topicCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginRight: 12,
    width: 160,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  topicTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  topicDesc: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
});